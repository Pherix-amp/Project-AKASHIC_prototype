
const DEFENSES_KEY = "akashicDefenses";
const SUBMISSIONS_KEY = "akashicSubmissions";

const scheduleForm = document.getElementById("defenseForm");
const thesisSelect = document.getElementById("defenseSubmission");
const defenseList = document.getElementById("defenseList");
const message = document.getElementById("defenseMessage");

function readStorage(key) {
    try {
        const data = JSON.parse(localStorage.getItem(key) || "[]");
        return Array.isArray(data) ? data : [];
    } catch {
        return [];
    }
}

function saveDefenses(defenses) {
    localStorage.setItem(DEFENSES_KEY, JSON.stringify(defenses));
}

function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, character => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[character]);
}

function loadSubmissions() {
    const submissions = readStorage(SUBMISSIONS_KEY);

    // Only approved chapters can be scheduled for defense.
    const eligible = submissions.filter(item =>
        item.status === "approved"
    );

    thesisSelect.innerHTML =
        '<option value="">Select an approved submission</option>' +
        eligible.map(item => `
            <option value="${escapeHTML(item.id)}">
                ${escapeHTML(item.groupTitle || "Thesis Group")}
                — ${escapeHTML(item.chapterLabel || "Thesis")}
                (${escapeHTML(item.submittedBy || "Student")})
            </option>
        `).join("");

    if (eligible.length === 0) {
        thesisSelect.innerHTML =
            '<option value="">No approved submissions available</option>';
    }
}

scheduleForm.addEventListener("submit", function(event) {
    event.preventDefault();

    const submissionId = thesisSelect.value;
    const submissions = readStorage(SUBMISSIONS_KEY);
    const submission = submissions.find(item =>
        String(item.id) === submissionId &&
        item.status === "approved"
    );

    if (!submission) {
        message.textContent =
            "Please select an approved submission.";
        return;
    }

    const defenses = readStorage(DEFENSES_KEY);

    // Update an existing schedule for this submission instead
    // of creating duplicate schedules.
    const existing = defenses.find(item =>
        item.submissionId === submissionId
    );

    const defense = {
        id: existing?.id || (
            "defense-" + Date.now() + "-" +
            Math.random().toString(36).slice(2, 7)
        ),
        submissionId: submissionId,
        submitterKey: submission.submitterKey || "",
        submittedBy: submission.submittedBy || "Student",
        groupTitle: submission.groupTitle || "Thesis Group",
        chapterLabel: submission.chapterLabel || "Thesis",
        date: document.getElementById("defenseDate").value,
        time: document.getElementById("defenseTime").value,
        venue: document.getElementById("defenseVenue").value.trim(),
        panelists: document.getElementById("defensePanelists").value.trim(),
        status: existing?.status || "Scheduled",
        result: existing?.result || "",
        remarks: existing?.remarks || "",
        updatedAt: new Date().toISOString()
    };

    if (existing) {
        const index = defenses.findIndex(item =>
            item.id === existing.id
        );
        defenses[index] = defense;
    } else {
        defenses.push(defense);
    }

    saveDefenses(defenses);

    message.textContent =
        "Defense schedule saved successfully.";

    scheduleForm.reset();
    renderDefenses();
    loadSubmissions();
});

function renderDefenses() {
    const defenses = readStorage(DEFENSES_KEY)
        .sort((a, b) =>
            (a.date + a.time).localeCompare(b.date + b.time)
        );

    if (defenses.length === 0) {
        defenseList.innerHTML =
            '<p class="empty">No defenses scheduled yet.</p>';
        return;
    }

    defenseList.innerHTML = defenses.map(defense => `
        <article class="defense-card">
            <h3>${escapeHTML(defense.groupTitle)}</h3>
            <p><strong>Student:</strong>
                ${escapeHTML(defense.submittedBy)}</p>
            <p><strong>Chapter:</strong>
                ${escapeHTML(defense.chapterLabel)}</p>
            <p><strong>Date:</strong>
                ${escapeHTML(defense.date)}</p>
            <p><strong>Time:</strong>
                ${escapeHTML(defense.time)}</p>
            <p><strong>Venue:</strong>
                ${escapeHTML(defense.venue)}</p>
            <p><strong>Panelists:</strong>
                ${escapeHTML(defense.panelists || "Not specified")}</p>
            <p><strong>Status:</strong>
                ${escapeHTML(defense.status)}</p>
            <p><strong>Result:</strong>
                ${escapeHTML(defense.result || "Not recorded")}</p>
            <p><strong>Remarks:</strong>
                ${escapeHTML(defense.remarks || "None")}</p>

            <div class="result-controls">
                <label>
                    Defense result
                    <select id="result-${escapeHTML(defense.id)}">
                        <option value="">Select result</option>
                        <option value="Passed"
                            ${defense.result === "Passed" ? "selected" : ""}>
                            Passed
                        </option>
                        <option value="Passed with Revisions"
                            ${defense.result === "Passed with Revisions" ? "selected" : ""}>
                            Passed with Revisions
                        </option>
                        <option value="Not Passed"
                            ${defense.result === "Not Passed" ? "selected" : ""}>
                            Not Passed
                        </option>
                    </select>
                </label>

                <label>
                    Remarks / required revisions
                    <textarea id="remarks-${escapeHTML(defense.id)}"
                        rows="2"
                        placeholder="Enter notes for the student">${escapeHTML(defense.remarks)}</textarea>
                </label>

                <button type="button"
                    data-save-result="${escapeHTML(defense.id)}">
                    Save Result
                </button>
            </div>
        </article>
    `).join("");
}

defenseList.addEventListener("click", function(event) {
    const button = event.target.closest("[data-save-result]");
    if (!button) return;

    const id = button.dataset.saveResult;
    const result = document.getElementById("result-" + id).value;
    const remarks = document.getElementById("remarks-" + id).value.trim();

    if (!result) {
        alert("Please select a defense result first.");
        return;
    }

    const defenses = readStorage(DEFENSES_KEY);
    const defense = defenses.find(item => item.id === id);

    if (!defense) {
        alert("Defense record not found.");
        return;
    }

    defense.result = result;
    defense.remarks = remarks;
    defense.status = "Completed";
    defense.updatedAt = new Date().toISOString();

    saveDefenses(defenses);
    renderDefenses();

    message.textContent = "Defense result saved successfully.";
});

document.getElementById("backToFaculty").addEventListener("click", () => {
    window.location.href = "faculty-dashboard.html";
});

document.getElementById("defenseLogout").addEventListener("click", () => {
    if (!confirm("Are you sure you want to log out?")) return;

    sessionStorage.removeItem("akashicDemoAccount");
    window.location.href = "login.html";
});

// Only faculty accounts can use this page.
try {
    const account = JSON.parse(
        sessionStorage.getItem("akashicDemoAccount") || "null"
    );

    if (!account || account.role !== "faculty") {
        window.location.replace("login.html");
    } else {
        document.getElementById("facultyName").textContent =
            account.fullName || "Faculty / Adviser";
        loadSubmissions();
        renderDefenses();
    }
} catch {
    window.location.replace("login.html");
}
