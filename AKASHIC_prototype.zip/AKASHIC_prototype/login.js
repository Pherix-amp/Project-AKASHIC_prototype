
const loginForm = document.getElementById("loginForm");
const loginMessage = document.getElementById("loginMessage");

loginForm.addEventListener("submit", function (event) {
    event.preventDefault();

    const email = document
        .getElementById("loginEmail")
        .value.trim()
        .toLowerCase();

    const password = document
        .getElementById("loginPassword")
        .value;

    let accounts = [];

    try {
        accounts = JSON.parse(
            localStorage.getItem("akashicDemoAccounts") || "[]"
        );
    } catch (error) {
        console.warn("Could not read demo accounts.", error);
    }

    // Support the older single-account version.
    if (accounts.length === 0) {
        const oldAccount = localStorage.getItem("akashicDemoAccount");

        if (oldAccount) {
            try {
                accounts = [JSON.parse(oldAccount)];
            } catch (error) {
                console.warn("Could not read the older demo account.", error);
            }
        }
    }

    const account = accounts.find(item =>
        item.email &&
        item.email.toLowerCase() === email &&
        item.password === password
    );

    if (!account) {
        loginMessage.textContent =
            "Incorrect email or password. Please try again.";
        loginMessage.className = "form-message error";
        return;
    }

    const emailDomain = email.split("@").pop();

    let role = account.role;

    // Determine the demo role from the email domain.
    if (emailDomain === "paterostechnologicalcollege.edu.ph") {
        role = "student";
    } else if (emailDomain === "gmail.com") {
        role = "faculty";
    } else {
        loginMessage.textContent =
            "Please use your PTC student email or faculty Gmail account.";
        loginMessage.className = "form-message error";
        return;
    }

    // Preserve the selected account and its role.
    const loggedInAccount = {
        ...account,
        role: role
    };

   sessionStorage.setItem(
    "akashicDemoAccount",
    JSON.stringify(loggedInAccount)
);

    loginMessage.textContent =
        "Login successful! Opening dashboard...";
    loginMessage.className = "form-message success";

    if (role === "faculty") {
        window.location.href = "faculty-dashboard.html";
    } else {
        window.location.href = "student-dashboard.html";
    }
});
