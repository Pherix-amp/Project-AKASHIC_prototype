const loginForm = document.getElementById("loginForm");
const loginMessage = document.getElementById("loginMessage");

loginForm.addEventListener("submit", function (event) {
    event.preventDefault();

    const email = document
        .getElementById("loginEmail")
        .value.trim()
        .toLowerCase();

    const password = document
        .getElementById("loginPassword")
        .value;

    const savedAccount = localStorage.getItem("akashicDemoAccount");

    if (!savedAccount) {
        loginMessage.textContent =
            "No demo account found. Please register first.";
        loginMessage.className = "form-message error";
        return;
    }

    const account = JSON.parse(savedAccount);

    if (
        account.email.toLowerCase() === email &&
        account.password === password
    ) {
        loginMessage.textContent = "Login successful! Opening dashboard...";
loginMessage.className = "form-message success";

window.location.href = "student-dashboard.html";
    } else {
        loginMessage.textContent =
            "Incorrect email or password. Please try again.";
        loginMessage.className = "form-message error";
    }
});