const registerForm = document.getElementById("registerForm");
const formMessage = document.getElementById("formMessage");

registerForm.addEventListener("submit", function (event) {
    event.preventDefault();

    const fullName = document.getElementById("fullName").value.trim();
    const studentId = document.getElementById("studentId").value.trim();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;
    const confirmPassword =
        document.getElementById("confirmPassword").value;

    formMessage.className = "form-message";
    formMessage.textContent = "";

    if (password !== confirmPassword) {
        formMessage.textContent = "Passwords do not match.";
        formMessage.classList.add("error");
        return;
    }

    const accountsKey = "akashicDemoAccounts";
    let accounts = JSON.parse(
        localStorage.getItem(accountsKey) || "[]"
    );

    // Preserve an older account when migrating from the single-account version.
    const oldAccount = localStorage.getItem("akashicDemoAccount");

    if (oldAccount) {
        try {
            const parsedAccount = JSON.parse(oldAccount);

            const alreadyIncluded = accounts.some(
                account =>
                    account.email.toLowerCase() ===
                    parsedAccount.email.toLowerCase()
            );

            if (!alreadyIncluded) {
                accounts.push(parsedAccount);
            }
        } catch (error) {
            console.warn("Could not migrate the old demo account.", error);
        }
    }

    const duplicate = accounts.some(account =>
        account.email.toLowerCase() === email.toLowerCase() ||
        account.studentId.toLowerCase() === studentId.toLowerCase()
    );

    if (duplicate) {
        formMessage.textContent =
            "An account with this email or Student ID already exists.";
        formMessage.classList.add("error");
        return;
    }

    const demoAccount = {
        fullName,
        studentId,
        email,
        password,
        role: "Student"
    };

    accounts.push(demoAccount);

    localStorage.setItem(accountsKey, JSON.stringify(accounts));

    formMessage.textContent =
        "Demo registration successful! Your sample account is saved in this browser.";
    formMessage.classList.add("success");

    registerForm.reset();
});