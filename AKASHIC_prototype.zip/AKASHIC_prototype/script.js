const registerForm = document.getElementById("registerForm");
const formMessage = document.getElementById("formMessage");
const loginLink = document.getElementById("loginLink");

registerForm.addEventListener("submit", function (event) {
    event.preventDefault();

    const fullName = document.getElementById("fullName").value.trim();
    const studentId = document.getElementById("studentId").value.trim();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;
    const confirmPassword =
        document.getElementById("confirmPassword").value;

    formMessage.className = "form-message";
    formMessage.textContent = "";

    if (password !== confirmPassword) {
        formMessage.textContent = "Passwords do not match.";
        formMessage.classList.add("error");
        return;
    }

    const existingAccount = localStorage.getItem("akashicDemoAccount");

    if (existingAccount) {
        const account = JSON.parse(existingAccount);

        if (
            account.email.toLowerCase() === email.toLowerCase() ||
            account.studentId.toLowerCase() === studentId.toLowerCase()
        ) {
            formMessage.textContent =
                "An account with this email or Student ID already exists.";
            formMessage.classList.add("error");
            return;
        }
    }

    const demoAccount = {
        fullName: fullName,
        studentId: studentId,
        email: email,
        password: password,
        role: "Student"
    };

    localStorage.setItem(
        "akashicDemoAccount",
        JSON.stringify(demoAccount)
    );

    formMessage.textContent =
        "Demo registration successful! Your sample account is saved in this browser.";
    formMessage.classList.add("success");

    registerForm.reset();
});