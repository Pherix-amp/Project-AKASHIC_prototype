const viewContainer = document.getElementById("viewContainer");
const navItems = document.querySelectorAll(".nav-item[data-view]");
const studentName = document.getElementById("studentName");

let activeView = "dashboard";

// ---------- Demo account (from the register page) ----------
const savedAccount = sessionStorage.getItem("akashicDemoAccount");
let account = null;

try {
    account = savedAccount ? JSON.parse(savedAccount) : null;
} catch {
    account = null;
}

studentName.textContent = account?.fullName || "Demo Student";

// ---------- Editor memory (variables the editor needs to remember) ----------
let thesisEditorSavedRange = null;  // where the cursor / selected text was
let currentEditorChapter = "chapter1"; // which chapter is open in the editor now
let editorDirty = false;            // true = there are changes not saved yet
let autoSaveTimer = null;           // the timer used by auto-save
let lastVersionTime = 0;            // when the last version snapshot was made

// ---------- Cursor / selection helpers ----------
// Clicking a toolbar button makes the editor lose the selected text.
// So we remember the selection and put it back before formatting.
function saveThesisEditorSelection() {
    const editor = document.getElementById("thesisEditor");
    const selection = window.getSelection();

    if (!editor || !selection || selection.rangeCount === 0) {
        return;
    }

    const range = selection.getRangeAt(0);

    if (editor.contains(range.commonAncestorContainer)) {
        thesisEditorSavedRange = range.cloneRange();
    }
}

function restoreThesisEditorSelection() {
    const editor = document.getElementById("thesisEditor");

    if (!editor || !thesisEditorSavedRange) {
        return;
    }

    editor.focus();

    const selection = window.getSelection();
    selection.removeAllRanges();
    selection.addRange(thesisEditorSavedRange);
}

// Put a piece of HTML (table, picture, diagram) where the cursor is.
// If there is no cursor yet, put it at the end of the chapter.
function insertAtCursor(html) {
    const editor = document.getElementById("thesisEditor");
    if (!editor) return;

    if (thesisEditorSavedRange) {
        restoreThesisEditorSelection();
        document.execCommand("insertHTML", false, html);
        saveThesisEditorSelection();
    } else {
        editor.insertAdjacentHTML("beforeend", html);
    }

    updateWordCount();
    scheduleAutoSave();
}

// ---------- Demo repository data ----------
const demoTheses = [
    {
        title: "Library Borrowing Management System",
        abstract: "A sample repository record demonstrating how students can search archived thesis titles and abstracts.",
        year: "2024"
    },
    {
        title: "Student Attendance Monitoring System",
        abstract: "A sample study record for demonstrating repository search in this prototype.",
        year: "2023"
    },
    {
        title: "Online Document Tracking System",
        abstract: "A sample record illustrating the discovery of related research topics.",
        year: "2025"
    }
];

// "Saved Draft: Yes" on the dashboard when any chapter was saved before.
function getDraft() {
    const hasChapter = Object.keys(localStorage).some(key =>
        key.startsWith("akashicChapter_")
    );
    return hasChapter ? "saved" : "";
}
// ---------- Persistent chapter submissions ----------
const SUBMISSIONS_KEY = "akashicSubmissions";
const SAMPLE_ADVISER_ID = "sample-adviser-001";

function getSubmissions() {
    try {
        const records = JSON.parse(
            localStorage.getItem(SUBMISSIONS_KEY) || "[]"
        );

        return Array.isArray(records) ? records : [];
    } catch (error) {
        console.error("Could not load submissions:", error);
        return [];
    }
}

function saveSubmissions(records) {
    try {
        localStorage.setItem(
            SUBMISSIONS_KEY,
            JSON.stringify(records)
        );
        return true;
    } catch (error) {
        console.error("Could not save submissions:", error);
        return false;
    }
}

function getStudentKey() {
    return (
        account?.email ||
        account?.studentId ||
        account?.fullName ||
        "demo-student"
    );
}

function renderSubmissionList() {
    const records = getSubmissions().filter(
        record => record.submitterKey === getStudentKey()
    );

    if (records.length === 0) {
        return `
            <p class="muted-text">
                No chapters have been submitted yet.
            </p>
        `;
    }

    records.sort(
        (a, b) =>
            new Date(b.submittedAt) - new Date(a.submittedAt)
    );

    return records.map(record => `
        <div class="result-item">
            <strong>${escapeHTML(record.chapterLabel)}</strong>

            <p class="muted-text">
                Submitted: ${escapeHTML(
                    new Date(record.submittedAt).toLocaleString()
                )}
            </p>

            <p>
                <strong>Status:</strong>
                ${escapeHTML(record.statusLabel)}
            </p>

            <p class="muted-text">
                This submitted copy is stored separately
                from your editable draft.
            </p>
        </div>
    `).join("");
}

function pageHeading(title, description, icon) {
    return `
        <div class="page-heading">
            <h2><ion-icon name="${icon}"></ion-icon>${title}</h2>
            <p>${description}</p>
        </div>
    `;
}

// =====================================================
// AUTO-SAVE (the new part)
// =====================================================
// How it works:
// 1. You type -> scheduleAutoSave() runs.
// 2. It waits 1 second after you STOP typing.
// 3. Then autoSaveNow() saves the chapter in the browser.
// 4. A new version is added at most once every minute.
// It also saves when you change chapter, change page, or close the tab.

function safeSet(key, value) {
    // localStorage can be full (big pictures). try/catch stops a crash.
    try {
        localStorage.setItem(key, value);
        return true;
    } catch {
        return false;
    }
}

function getVersions(chapter) {
    try {
        return JSON.parse(localStorage.getItem(`akashicVersions_${chapter}`) || "[]");
    } catch {
        return [];
    }
}

function saveChapter(chapter, html, addVersion) {
    if (!safeSet(getChapterKey(chapter), html)) {
        return false;
    }

    safeSet("akashicActiveChapter", chapter);

    if (addVersion) {
        const versions = getVersions(chapter);

        // Only add a version if the text really changed.
        if (!versions.length || versions[0].content !== html) {
            versions.unshift({
                date: new Date().toLocaleString(),
                content: html
            });
            safeSet(
                `akashicVersions_${chapter}`,
                JSON.stringify(versions.slice(0, 10))
            );
            lastVersionTime = Date.now();
        }
    }

    return true;
}

function setSaveStatus(text) {
    const status = document.getElementById("editorSaveStatus");
    if (status) status.textContent = text;
}

function scheduleAutoSave() {
    editorDirty = true;
    setSaveStatus("Unsaved changes... auto-save will run when you stop typing.");

    clearTimeout(autoSaveTimer);
    autoSaveTimer = setTimeout(autoSaveNow, 1000);
}

function autoSaveNow() {
    const editor = document.getElementById("thesisEditor");

    if (!editor || !editorDirty) {
        return;
    }

    clearTimeout(autoSaveTimer);

    const addVersion = Date.now() - lastVersionTime > 60000;
    const saved = saveChapter(currentEditorChapter, editor.innerHTML, addVersion);

    if (saved) {
        editorDirty = false;
        setSaveStatus(`Auto-saved at ${new Date().toLocaleTimeString()}`);
    } else {
        setSaveStatus("Could not save. Browser storage may be full (try smaller images).");
    }
}

// Last chance to save when the tab is closed or refreshed.
window.addEventListener("beforeunload", autoSaveNow);

// =====================================================
// PAGES
// =====================================================
function renderDashboard() {
    viewContainer.innerHTML = `
        ${pageHeading(
            "Dashboard",
            "Your thesis workspace at a glance.",
            "grid-outline"
        )}

        <section class="welcome-panel">
            <h3>Welcome, ${escapeHTML(account?.fullName || "Student")}!</h3>
            <p>
                Welcome to Project AKASHIC. Use the sidebar to work with
                thesis drafts, submissions, reviews, similarity-check
                demonstrations, and repository search.
            </p>
        </section>

        <div class="stats-grid">
            <section class="stat-card">
                <div class="stat-label">Saved Draft</div>
                <div class="stat-value">${getDraft() ? "Yes" : "No"}</div>
            </section>
            <section class="stat-card">
                <div class="stat-label">Submission Status</div>
                <div class="stat-value" style="font-size:18px">Not submitted</div>
            </section>
            <section class="stat-card">
                <div class="stat-label">Defense Schedule</div>
                <div class="stat-value" style="font-size:18px">Not scheduled</div>
            </section>
        </div>

        <section class="content-card">
            <h3>Get Started</h3>
            <p class="muted-text">
                Open your thesis, write a chapter, and it will be saved
                automatically before you explore the other prototype sections.
            </p>
            <div class="action-row">
                <button class="primary-action" data-go="thesis">
                    <ion-icon name="create-outline"></ion-icon>
                    Open My Thesis
                </button>
                <button class="secondary-action" data-go="repository">
                    <ion-icon name="search-outline"></ion-icon>
                    Search Repository
                </button>
            </div>
        </section>

        <p class="muted-text">
            Prototype notice: displayed statuses are demonstration data.
            No faculty review, real similarity analysis, or defense booking
            occurs in this version.
        </p>
    `;
}

const thesisChapters = [
    { value: "chapter1", label: "Chapter 1 — The Problem and Its Background" },
    { value: "chapter2", label: "Chapter 2 — Review of Related Literature" },
    { value: "chapter3", label: "Chapter 3 — Methodology" },
    { value: "chapter4", label: "Chapter 4 — Results and Discussion" },
    { value: "chapter5", label: "Chapter 5 — Summary and Recommendations" },
    { value: "references", label: "References" }
];

function getChapterKey(chapter) {
    return `akashicChapter_${chapter}`;
}

function getChapterContent(chapter) {
    const savedContent = localStorage.getItem(getChapterKey(chapter));

    // An empty string is a valid saved chapter.
    // Only show the starter text if this chapter was never saved.
    if (savedContent !== null) {
        return savedContent;
    }

    const chapterLabel =
        thesisChapters.find(item => item.value === chapter)?.label ||
        "Thesis Chapter";

    return `<h2>${escapeHTML(chapterLabel)}</h2>
        <p>Start writing your chapter here...</p>`;
}

function updateWordCount() {
    const editor = document.getElementById("thesisEditor");
    const counter = document.getElementById("editorWordCount");

    if (!editor || !counter) return;

    const text = editor.innerText.trim();
    const words = text ? text.split(/\s+/).length : 0;
    counter.textContent = `${words} words`;
}

function renderThesis() {
    const currentChapter =
        localStorage.getItem("akashicActiveChapter") || "chapter1";

    // Reset the editor memory for this fresh page.
    currentEditorChapter = currentChapter;
    thesisEditorSavedRange = null;
    editorDirty = false;
    lastVersionTime = 0;

    viewContainer.innerHTML = `
        ${pageHeading(
            "Thesis Editor",
            "Write and format your thesis chapter in the AKASHIC workspace.",
            "document-text-outline"
        )}

        <div class="demo-label">BROWSER-BASED EDITOR PROTOTYPE</div>

        <section class="content-card">
            <h3>Chapter Workspace</h3>

            <div class="field-group">
                <label for="editorChapter">Select Chapter</label>
                <select id="editorChapter">
                    ${thesisChapters.map(chapter => `
                        <option value="${chapter.value}"
                            ${chapter.value === currentChapter ? "selected" : ""}>
                            ${escapeHTML(chapter.label)}
                        </option>
                    `).join("")}
                </select>
            </div>

            <div class="editor-toolbar" role="toolbar" aria-label="Document formatting">
                <select id="editorFont" aria-label="Font family">
                    <option value="Times New Roman">Times New Roman</option>
                    <option value="Arial">Arial</option>
                    <option value="Georgia">Georgia</option>
                    <option value="Calibri">Calibri</option>
                </select>

                <select id="editorFontSize" aria-label="Font size">
                    <option value="2">10 pt</option>
                    <option value="3" selected>12 pt</option>
                    <option value="4">14 pt</option>
                    <option value="5">18 pt</option>
                    <option value="6">24 pt</option>
                </select>

                <button type="button" data-editor-command="bold" title="Bold"><b>B</b></button>
                <button type="button" data-editor-command="italic" title="Italic"><i>I</i></button>
                <button type="button" data-editor-command="underline" title="Underline"><u>U</u></button>
                <button type="button" data-editor-command="strikeThrough" title="Strike through"><s>S</s></button>

                <button type="button" data-editor-command="justifyLeft" title="Align left">Left</button>
                <button type="button" data-editor-command="justifyCenter" title="Center">Center</button>
                <button type="button" data-editor-command="justifyRight" title="Align right">Right</button>
                <button type="button" data-editor-command="justifyFull" title="Justify">Justify</button>

                <button type="button" data-editor-command="insertUnorderedList" title="Bulleted list">• List</button>
                <button type="button" data-editor-command="insertOrderedList" title="Numbered list">1. List</button>
                <button type="button" data-editor-command="undo" title="Undo">↶ Undo</button>
                <button type="button" data-editor-command="redo" title="Redo">↷ Redo</button>

                <button type="button" id="insertTable">Insert Table</button>
                <button type="button" id="insertDiagram">Insert Diagram</button>
                <!-- Font color -->
<label for="editorFontColor">Font color</label>
<input type="color" id="editorFontColor" value="#222222" title="Change font color">

<!-- Text highlight -->
<label for="editorHighlightColor">Highlight</label>
<input type="color" id="editorHighlightColor" value="#FFFF00"
       title="Choose highlight color">

<button type="button" id="applyHighlight">
    Apply Highlight
</button>

<button type="button" id="removeHighlight">
    Remove Highlight
</button>



                <button type="button" id="insertImage">Insert Image</button>
                <input id="editorImageFile" type="file" accept="image/*" hidden>
            </div>
            

            <p class="muted-text">
                Select text before using formatting tools. This editor is
                a prototype; check the final document against official IICT
                formatting guidelines.
            </p>

            <div id="thesisEditor"
                class="thesis-editor"
                contenteditable="true"
                role="textbox"
                aria-label="Thesis chapter document"
                aria-multiline="true"
                spellcheck="true">${getChapterContent(currentChapter)}</div>

            <div class="editor-footer">
                <span id="editorSaveStatus" class="muted-text">
                    Auto-save is on. Your chapter is saved in this browser.
                </span>
                <span id="editorWordCount" class="muted-text">0 words</span>
            </div>

            <div class="action-row">
                <button class="primary-action" id="saveDraft">
                    <ion-icon name="save-outline"></ion-icon>
                    Save Chapter
                </button>

                <button class="secondary-action" id="clearChapter">
                    <ion-icon name="trash-outline"></ion-icon>
                    Clear Chapter
                </button>

                <button class="secondary-action" id="resetDemoThesis">
                    <ion-icon name="refresh-outline"></ion-icon>
                    Reset Demo Thesis
                </button>

                <button class="secondary-action" id="showVersions">
                    <ion-icon name="time-outline"></ion-icon>
                    Version History
                </button>

                <button class="secondary-action" data-go="submissions">
                    <ion-icon name="paper-plane-outline"></ion-icon>
                    Continue to Submission
                </button>
            </div>

            <p id="thesisMessage" class="status-message" role="status"></p>
            <div id="versionHistory" aria-live="polite"></div>
        </section>

        <section class="content-card">
            <h3>Next: Review and Annotation</h3>
            <p class="muted-text">
                The next editor upgrade will add professor comments,
                highlighted passages, strike-through marks, drawing
                annotations, suggested edits, and accept/reject actions.
                Those review actions will be clearly identified as demo
                data until real faculty accounts and a backend are added.
            </p>
            <div class="action-row">
                <button class="secondary-action" data-go="reviews">
                    <ion-icon name="chatbubbles-outline"></ion-icon>
                    Open Reviews & Comments
                </button>
            </div>
        </section>
    `;

    const editor = document.getElementById("thesisEditor");

    // Remember the cursor position.
    editor.addEventListener("mouseup", saveThesisEditorSelection);
    editor.addEventListener("keyup", saveThesisEditorSelection);

    // Every time you type: count words and start the auto-save timer.
    editor.addEventListener("input", () => {
        saveThesisEditorSelection();
        updateWordCount();
        scheduleAutoSave();
    });

    updateWordCount();
}

function renderSubmissions() {
    viewContainer.innerHTML = `
        ${pageHeading(
            "Submissions",
            "Submit a saved thesis chapter for the next workflow stage.",
            "cloud-upload-outline"
        )}

        <section class="content-card">
            <h3>Submit a Chapter</h3>

            <p class="muted-text">
                Save your chapter in My Thesis before submitting.
                This prototype stores a separate snapshot in this browser.
                It does not upload the chapter to a real server.
            </p>

            <div class="field-group">
                <label for="chapterChoice">Chapter</label>

                <select id="chapterChoice">
                    ${thesisChapters.map(chapter => `
                        <option value="${chapter.value}">
                            ${escapeHTML(chapter.label)}
                        </option>
                    `).join("")}
                </select>
            </div>

            <button class="primary-action" id="submitChapter">
                <ion-icon name="paper-plane-outline"></ion-icon>
                Submit Chapter
            </button>

            <p id="submissionMessage"
               class="status-message"
               role="status"></p>
        </section>

        <section class="content-card">
            <h3>My Submitted Chapters</h3>

            <div id="mySubmissionList">
                ${renderSubmissionList()}
            </div>
        </section>

        <section class="content-card">
            <h3>Submission Process</h3>

            <p class="muted-text">
                Draft → Submission → Similarity Check →
                Faculty Review → Revision or Approval.
            </p>

            <p class="muted-text">
                Similarity checking and faculty review are not
                connected to submissions yet in this milestone.
            </p>
        </section>
    `;
}


function renderReviews() {
    const records = getSubmissions().filter(
        record => record.submitterKey === getStudentKey()
    );

    const reviewedRecords = records.filter(record =>
        record.reviewFeedback ||
        record.status === "revision_requested" ||
        record.status === "approved"
    );

    const reviewContent = reviewedRecords.length
        ? reviewedRecords.map(record => {
            const feedback = record.reviewFeedback || {};

            return `
                <div class="result-item">
                    <h3>${escapeHTML(
                        record.chapterLabel || record.chapter || "Thesis Chapter"
                    )}</h3>

                    <p>
                        <strong>Status:</strong>
                        ${escapeHTML(
                            record.statusLabel || record.status || "Under review"
                        )}
                    </p>

                    <p class="muted-text">
                        Submitted: ${escapeHTML(
                            record.submittedAt
                                ? new Date(record.submittedAt).toLocaleString()
                                : "Unknown date"
                        )}
                    </p>

                    <hr>

                    <h4>Faculty Comments</h4>
                    <p>${escapeHTML(
                        feedback.generalComment || "No general comments provided."
                    )}</p>

                    <h4>Original Text</h4>
                    <p>${escapeHTML(
                        feedback.originalText || "No original text specified."
                    )}</p>

                    <h4>Suggested Replacement</h4>
                    <p>${escapeHTML(
                        feedback.suggestedText || "No suggested replacement provided."
                    )}</p>

                    <p class="muted-text">
                        ${feedback.savedAt
                            ? "Feedback saved: " + escapeHTML(
                                new Date(feedback.savedAt).toLocaleString()
                            )
                            : ""}
                    </p>

                    ${record.status === "revision_requested" ? `
                        <p><strong>Next step:</strong> Open My Thesis, revise your chapter, save it, and submit it again.</p>
                    ` : ""}

                    ${record.status === "approved" ? `
                        <p><strong>Next step:</strong> Your chapter is approved. Follow your faculty's instructions for the next stage.</p>
                    ` : ""}
                </div>
            `;
        }).join("")
        : `<p class="muted-text">
            No faculty feedback is available for your submissions yet.
           </p>`;

    viewContainer.innerHTML = `
        ${pageHeading(
            "Reviews & Comments",
            "Read faculty feedback and check the status of your submitted chapters.",
            "chatbubbles-outline"
        )}

        <section class="content-card">
            <h3>My Faculty Reviews</h3>
            ${reviewContent}

            <div class="action-row">
                <button class="secondary-action" data-go="thesis">
                    <ion-icon name="create-outline"></ion-icon>
                    Return to Thesis Draft
                </button>

                <button class="secondary-action" data-go="submissions">
                    <ion-icon name="paper-plane-outline"></ion-icon>
                    View Submissions
                </button>
            </div>
        </section>
    `;
}


      

function renderSimilarity() {
    viewContainer.innerHTML = `
        ${pageHeading(
            "Similarity Checking",
            "Learn how the similarity-checking step fits into the submission workflow.",
            "copy-outline"
        )}

        <section class="content-card">
            <h3>Similarity Check Demonstration</h3>
            <p class="muted-text">
                The proposal specifies an adjustable threshold of 75–80%.
                This prototype does not compare documents or calculate
                a real similarity percentage.
            </p>

            <div class="field-group">
                <label for="similarityThreshold">Demo threshold</label>
                <select id="similarityThreshold">
                    <option value="75">75%</option>
                    <option value="76">76%</option>
                    <option value="77">77%</option>
                    <option value="78">78%</option>
                    <option value="79">79%</option>
                    <option value="80">80%</option>
                </select>
            </div>

            <button class="primary-action" id="demoSimilarity">
                Run Workflow Demonstration
            </button>
            <p id="similarityMessage" class="status-message" role="status"></p>
        </section>
    `;
}

function renderAssistant() {
    viewContainer.innerHTML = `
        ${pageHeading(
            "AI Chat Assistance",
            "Ask about thesis formatting, title clarity, or using AKASHIC.",
            "chatbox-ellipses-outline"
        )}

        <section class="content-card">
            <div class="demo-label">LIMITED PROTOTYPE ASSISTANT</div>
            <h3>How can I help?</h3>
            <p class="muted-text">
                This demo provides predefined guidance only. It does not
                connect to an AI service or generate thesis content.
            </p>

            <div class="field-group">
                <label for="helpQuestion">Your question</label>
                <textarea id="helpQuestion"
                    placeholder="Ask about formatting, title clarity, or using the system..."></textarea>
            </div>

            <button class="primary-action" id="askAssistant">
                <ion-icon name="send-outline"></ion-icon>
                Get Guidance
            </button>
            <p id="assistantResponse" class="status-message" role="status"></p>
        </section>
    `;
}

function renderDefense() {
    viewContainer.innerHTML = `
        ${pageHeading(
            "Defense Schedule & Results",
            "Review the defense stages defined in the thesis workflow.",
            "calendar-outline"
        )}

        <section class="content-card">
            <h3>Defense Information</h3>
            <div class="demo-label">NO DEFENSE SCHEDULED</div>
            <p class="muted-text">
                In the complete system, the faculty schedules the defense
                and records the result. Possible outcomes are Passed,
                Passed with Revisions, and Not Passed.
            </p>
            <p class="muted-text">
                A successful thesis can proceed to archiving according
                to the proposal's approval and revision requirements.
            </p>
        </section>
    `;
}

function renderRepository() {
    viewContainer.innerHTML = `
        ${pageHeading(
            "Research Repository",
            "Browse archived research approved by the Thesis Management System.",
            "library-outline"
        )}

        <section class="content-card">
            <h3>Search Repository</h3>

            <p class="muted-text">
                This prototype demonstrates how approved research may be
                searched and viewed. All records below are sample data only.
            </p>

            <div class="field-group">
                <label for="repositoryQuery">Research Title or Keyword</label>
                <input
                    id="repositoryQuery"
                    type="search"
                    placeholder="Search research title or keyword..."
                >
            </div>

            <button class="primary-action" id="searchRepository">
                <ion-icon name="search-outline"></ion-icon>
                Search Research
            </button>

            <div id="repositoryResults">

                <div class="content-card" style="margin-top:20px;">
                    <h3>Sample Archived Research</h3>

                    <p><strong>Research Title:</strong><br>
                    Smart Attendance Monitoring System</p>

                    <p><strong>Abstract:</strong><br>
                    A web-based attendance monitoring system developed for
                    educational institutions.</p>

                    <p><strong>Program:</strong>
                    Bachelor of Science in Information Technology</p>

                    <p><strong>Academic Year:</strong>
                    2024–2025</p>

                    <p><strong>Thesis Status:</strong>
                    Approved and Archived</p>

                    <p><strong>Access Level:</strong>
                    Public Abstract / Faculty Full Text</p>

                    <p><strong>Assigned Adviser:</strong>
                    Prof. Juan Dela Cruz</p>

                </div>

            </div>
        </section>

        <section class="content-card">

            <h3>Repository Information</h3>

            <table class="info-table">
                <tr>
                    <td><strong>Status</strong></td>
                    <td>Approved & Archived</td>
                </tr>

                <tr>
                    <td><strong>Repository</strong></td>
                    <td>Institutional Thesis Repository</td>
                </tr>

                <tr>
                    <td><strong>Access</strong></td>
                    <td>
                        Students and Public may view research information
                        and abstracts only.
                    </td>
                </tr>

                <tr>
                    <td><strong>Faculty / Admin</strong></td>
                    <td>
                        May access complete archived thesis documents
                        according to permissions.
                    </td>
                </tr>

            </table>

        </section>
    `;
}



function renderNotifications() {
    const notifications = JSON.parse(
        localStorage.getItem("akashicNotifications") || "[]"
    );

    const studentKey = getStudentKey();

    // Mark this student's notifications as read.
    const updatedNotifications = notifications.map(notification => {
        if (notification.recipientKey === studentKey) {
            return {
                ...notification,
                read: true
            };
        }

        return notification;
    });

    localStorage.setItem(
        "akashicNotifications",
        JSON.stringify(updatedNotifications)
    );

    const myNotifications = updatedNotifications
        .filter(notification =>
            notification.recipientKey === studentKey
        )
        .sort((a, b) =>
            new Date(b.createdAt) - new Date(a.createdAt)
        );

    const notificationContent = myNotifications.length
        ? myNotifications.map(notification => `
            <div class="result-item">
                <strong>${escapeHTML(
                    notification.title || "Thesis Update"
                )}</strong>

                <p>${escapeHTML(
                    notification.message ||
                    "Your thesis status has been updated."
                )}</p>

                <span class="muted-text">
                    ${escapeHTML(
                        notification.createdAt
                            ? new Date(notification.createdAt).toLocaleString()
                            : ""
                    )}
                </span>

                <p><strong>Status:</strong> Read</p>
            </div>
        `).join("")
        : `<p class="muted-text">
            No faculty notifications are available for this account yet.
           </p>`;

    viewContainer.innerHTML = `
        ${pageHeading(
            "Notifications",
            "View updates about your thesis submissions and faculty reviews.",
            "notifications-outline"
        )}

        <section class="content-card">
            <h3>My Notifications</h3>
            ${notificationContent}

            <div class="action-row">
                <button class="secondary-action" data-go="reviews">
                    <ion-icon name="chatbubbles-outline"></ion-icon>
                    View Reviews & Comments
                </button>

                <button class="secondary-action" data-go="submissions">
                    <ion-icon name="paper-plane-outline"></ion-icon>
                    View Submissions
                </button>
            </div>
        </section>
    `;
    
    updateNotificationBadge();
}



// Makes text safe before putting it inside HTML.
function escapeHTML(value) {
    return String(value).replace(/[&<>"']/g, character => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[character]);
}

// =====================================================
// NAVIGATION
// =====================================================
function showView(view) {
    // Save the chapter first so nothing is lost when leaving the editor.
    autoSaveNow();
    editorDirty = false;
    clearTimeout(autoSaveTimer);

    activeView = view;

    navItems.forEach(button => {
        button.classList.toggle("active", button.dataset.view === view);
    });

    const renderers = {
        dashboard: renderDashboard,
        thesis: renderThesis,
        submissions: renderSubmissions,
        reviews: renderReviews,
        similarity: renderSimilarity,
        assistant: renderAssistant,
        defense: renderDefense,
        repository: renderRepository,
        notifications: renderNotifications
    };

    (renderers[view] || renderDashboard)();
}

navItems.forEach(button => {
    button.addEventListener("click", () => showView(button.dataset.view));
});

// =====================================================
// ONE CLICK HANDLER for everything inside the page
// (the page changes, so we listen on viewContainer which always exists)
// =====================================================
viewContainer.addEventListener("click", event => {
    const navigationButton = event.target.closest("[data-go]");
    const editorCommandButton = event.target.closest("[data-editor-command]");

    // --- Buttons that open another page ---
    if (navigationButton) {
        showView(navigationButton.dataset.go);
        return;
    }

    // --- Toolbar buttons: Bold, Italic, lists, undo, etc. ---
    if (editorCommandButton) {
        restoreThesisEditorSelection();
        document.execCommand(editorCommandButton.dataset.editorCommand, false, null);
        saveThesisEditorSelection();
        updateWordCount();
        scheduleAutoSave();
        return;
    }

    // --- Save Chapter (manual save, always makes a version) ---
    if (event.target.closest("#saveDraft")) {
        const editor = document.getElementById("thesisEditor");
        const saved = saveChapter(currentEditorChapter, editor.innerHTML, true);

        if (saved) {
            editorDirty = false;
            setSaveStatus(`Saved at ${new Date().toLocaleTimeString()}`);
            document.getElementById("thesisMessage").textContent =
                "Chapter saved. This is local prototype storage, not a server backup.";
        } else {
            document.getElementById("thesisMessage").textContent =
                "Could not save. Browser storage may be full (try smaller images).";
        }
        return;
    }

    // --- Clear Chapter ---
    if (event.target.closest("#clearChapter")) {
        if (confirm("Clear everything in this chapter?")) {
            document.getElementById("thesisEditor").innerHTML = "";
            updateWordCount();
            scheduleAutoSave();
        }
        return;
    }

    // --- Reset Demo Thesis ---
    if (event.target.closest("#resetDemoThesis")) {
        if (confirm("Delete all saved chapters and versions?")) {
            clearTimeout(autoSaveTimer);
            editorDirty = false;

            // Remove every AKASHIC key except the demo account.
            Object.keys(localStorage)
               .filter(key =>
    key.startsWith("akashic") &&
    key !== "akashicDemoAccount" &&
    key !== SUBMISSIONS_KEY
)
                .forEach(key => localStorage.removeItem(key));

            renderThesis();
        }
        return;
    }

    // --- Version History ---
    if (event.target.closest("#showVersions")) {
        const versions = getVersions(currentEditorChapter);
        const history = document.getElementById("versionHistory");

        if (!versions.length) {
            history.innerHTML =
                '<p class="muted-text">No saved versions yet. Type or press Save Chapter to create the first version.</p>';
        } else {
            history.innerHTML = `
                <h3>Saved Versions</h3>
                ${versions.map((version, index) => `
                    <div class="result-item">
                        <strong>Version ${versions.length - index}</strong>
                        <p class="muted-text">${escapeHTML(version.date)}</p>
                        <button type="button" class="secondary-action"
                            data-restore-version="${index}">
                            Restore this version
                        </button>
                    </div>
                `).join("")}
            `;
        }
        return;
    }

    // --- Restore a version ---
    const restoreButton = event.target.closest("[data-restore-version]");

    if (restoreButton) {
        const versions = getVersions(currentEditorChapter);
        const version = versions[Number(restoreButton.dataset.restoreVersion)];

        if (version) {
            document.getElementById("thesisEditor").innerHTML = version.content;
            updateWordCount();
            scheduleAutoSave();
            document.getElementById("thesisMessage").textContent =
                "Version loaded into the editor. It will be auto-saved as the current draft.";
        }
        return;
    }

    // --- Insert Table (at the cursor) ---
    if (event.target.closest("#insertTable")) {
        const rows = Number(prompt("How many table rows? (1–10)", "3"));
        const columns = Number(prompt("How many table columns? (1–8)", "3"));

        if (Number.isInteger(rows) && rows >= 1 && rows <= 10 &&
            Number.isInteger(columns) && columns >= 1 && columns <= 8) {

            const cell = '<td style="border:1px solid #444;padding:6px;">&nbsp;</td>';
            const row = `<tr>${cell.repeat(columns)}</tr>`;

            insertAtCursor(
                `<table style="border-collapse:collapse;width:100%;margin:12px 0;">${row.repeat(rows)}</table><p><br></p>`
            );
        }
        return;
    }

    
    /* Apply font color to selected text */
if (event.target.closest("#editorFontColor")) {
    const color = document.getElementById("editorFontColor").value;

    document.getElementById("thesisEditor").focus();
    document.execCommand("foreColor", false, color);

    scheduleAutoSave();
    return;
    
}

/* Apply or remove text highlight */
if (event.target.closest("#applyHighlight")) {
    const editor = document.getElementById("thesisEditor");
    const color = document.getElementById("editorHighlightColor").value;

    editor.focus();
    document.execCommand("hiliteColor", false, color);

    scheduleAutoSave();
    return;
}

if (event.target.closest("#removeHighlight")) {
    const editor = document.getElementById("thesisEditor");

    editor.focus();
    document.execCommand("hiliteColor", false, "transparent");
    document.execCommand("backColor", false, "transparent");

    scheduleAutoSave();
    return;
}
    // --- Insert Image (opens the file picker) ---
    if (event.target.closest("#insertImage")) {
        document.getElementById("editorImageFile").click();
        return;
    }

    // --- Submit a saved chapter ---
if (event.target.closest("#submitChapter")) {
    const chapter = document.getElementById("chapterChoice").value;
    const message = document.getElementById("submissionMessage");

    const savedHTML = localStorage.getItem(
        getChapterKey(chapter)
    );

    if (savedHTML === null || !savedHTML.trim()) {
        message.textContent =
            "No saved chapter found. Open My Thesis, write your chapter, and click Save Chapter first.";
        return;
    }

    const plainText = savedHTML
        .replace(/<[^>]*>/g, " ")
        .replace(/&nbsp;/g, " ")
        .trim();

    if (!plainText) {
        message.textContent =
            "Your saved chapter appears to be empty. Please add content before submitting.";
        return;
    }

    const chapterInfo = thesisChapters.find(
        item => item.value === chapter
    );

    const records = getSubmissions();

    const submission = {
        id: `submission-${Date.now()}`,
        chapter: chapter,
        chapterLabel: chapterInfo
            ? chapterInfo.label
            : chapter,
        submittedAt: new Date().toISOString(),
        submittedBy: account?.fullName || "Demo Student",
        submitterKey: getStudentKey(),
        groupTitle: "Demo Thesis Group",
        adviserId: SAMPLE_ADVISER_ID,
        status: "awaiting_similarity_check",
        statusLabel: "Awaiting similarity check",
        snapshotHTML: savedHTML,
        reviewComments: [],
        decision: null
    };

    records.push(submission);

if (!saveSubmissions(records)) {
    message.textContent =
        "Could not save the submission. Browser storage may be full.";
    return;
}

// --- Simulated similarity check ---
const similarityScore = 70;
const similarityThreshold = 75;

if (similarityScore >= similarityThreshold) {
    submission.status = "flagged";
    submission.statusLabel =
        `Flagged for review (${similarityScore}% simulated similarity)`;

    submission.similarityScore = similarityScore;
    submission.similarityThreshold = similarityThreshold;
} else {
    submission.status = "pending_faculty_review";
    submission.statusLabel =
        `Passed simulated check (${similarityScore}% similarity) — Awaiting faculty review`;

    submission.similarityScore = similarityScore;
    submission.similarityThreshold = similarityThreshold;
}

if (!saveSubmissions(records)) {
    message.textContent =
        "Could not save the similarity result. Please try again.";
    return;
}

    message.textContent =
        "Chapter submitted successfully in the prototype. Your saved submission record is now available below.";

    document.getElementById("mySubmissionList").innerHTML =
        renderSubmissionList();

    return;
}

    // --- Similarity page ---
    if (event.target.closest("#demoSimilarity")) {
        const threshold = document.getElementById("similarityThreshold").value;
        document.getElementById("similarityMessage").textContent =
            `Workflow demonstration completed using a ${threshold}% example threshold. No document was scanned and no similarity score was calculated.`;
        return;
    }

    // --- AI assistant page ---
    if (event.target.closest("#askAssistant")) {
        const question = document.getElementById("helpQuestion").value.trim();
        const response = document.getElementById("assistantResponse");

        if (!question) {
            response.textContent = "Please enter a question first.";
            response.className = "status-message error";
            return;
        }

        const normalized = question.toLowerCase();
        let guidance;

        if (
            normalized.includes("format") ||
            normalized.includes("font") ||
            normalized.includes("margin")
        ) {
            guidance =
                "Formatting guidance: the proposal specifies IICT format, Times New Roman, 12-point font, and justified text. Confirm any additional formatting rules with your adviser or official guidelines.";
        } else if (
            normalized.includes("title") ||
            normalized.includes("topic")
        ) {
            guidance =
                "Title guidance: aim for a clear, specific title that identifies the study's focus and scope. Discuss title revisions with your adviser.";
        } else {
            guidance =
                "System guidance: use My Thesis to write and auto-save your chapters, Submissions to demonstrate the chapter workflow, Reviews & Comments to understand revisions, and Repository Search to find sample related topics. This is predefined demo guidance, not a live AI response.";
        }

        response.textContent = guidance;
        response.className = "status-message";
        return;
    }

    // --- Repository search ---
    if (event.target.closest("#searchRepository")) {
        const query = document.getElementById("repositoryQuery")
            .value.trim().toLowerCase();
        const results = document.getElementById("repositoryResults");

        const matches = demoTheses.filter(thesis =>
            `${thesis.title} ${thesis.abstract}`.toLowerCase().includes(query)
        );

        if (!matches.length) {
            results.innerHTML = `
                <p class="muted-text">No matching sample records found.</p>
            `;
            return;
        }

        results.innerHTML = matches.map(thesis => `
            <div class="result-item">
                <strong>${escapeHTML(thesis.title)}</strong>
                <p class="muted-text">${escapeHTML(thesis.abstract)}</p>
                <span class="muted-text">Sample year: ${escapeHTML(thesis.year)}</span>
            </div>
        `).join("");
    }
});

// =====================================================
// DROPDOWNS AND FILE PICKER (also on viewContainer, so they work
// even though these elements appear only on the Thesis page)
// =====================================================
viewContainer.addEventListener("change", event => {
    const id = event.target.id;

    // Change chapter: save the old one first, then load the new one.
    if (id === "editorChapter") {
        autoSaveNow();

        const chapter = event.target.value;
        currentEditorChapter = chapter;
        thesisEditorSavedRange = null;
        editorDirty = false;
        lastVersionTime = 0;
        safeSet("akashicActiveChapter", chapter);

        document.getElementById("thesisEditor").innerHTML = getChapterContent(chapter);
        document.getElementById("versionHistory").innerHTML = "";
        document.getElementById("thesisMessage").textContent = "";
        setSaveStatus("Showing the selected chapter's saved draft.");
        updateWordCount();
    }

    // Font family
    if (id === "editorFont") {
        restoreThesisEditorSelection();
        document.execCommand("fontName", false, event.target.value);
        saveThesisEditorSelection();
        scheduleAutoSave();
    }

    // Font size
    if (id === "editorFontSize") {
        restoreThesisEditorSelection();
        document.execCommand("fontSize", false, event.target.value);
        saveThesisEditorSelection();
        scheduleAutoSave();
    }

    // Image file picked
    if (id === "editorImageFile") {
        const file = event.target.files?.[0];

        if (!file) return;

        if (!file.type.startsWith("image/")) {
            alert("Please select an image file.");
            event.target.value = "";
            return;
        }

        if (file.size > 2 * 1024 * 1024) {
            alert("For this prototype, please use an image smaller than 2 MB.");
            event.target.value = "";
            return;
        }

        const reader = new FileReader();

        reader.onload = () => {
            insertAtCursor(
                `<img src="${reader.result}" alt="Inserted thesis figure" style="max-width:100%;">`
            );
        };

        reader.readAsDataURL(file);
        event.target.value = "";
    }
});

// Keeps the selected text when you press a toolbar button
// (buttons normally steal the focus from the editor).
viewContainer.addEventListener("mousedown", event => {
    if (event.target.closest(".editor-toolbar button")) {
        saveThesisEditorSelection();
        event.preventDefault();
    }
});

// =====================================================
// LOGOUT
// =====================================================
document.getElementById("logoutButton").addEventListener("click", () => {
    if (window.confirm("Return to the login page?")) {
        autoSaveNow();
        window.location.href = "login.html";
    }
});

// Start on the dashboard.
showView("dashboard");

function updateNotificationBadge() {
    const badge = document.getElementById("notificationBadge");

    if (!badge) return;

    const notifications = JSON.parse(
        localStorage.getItem("akashicNotifications") || "[]"
    );

    const studentKey = getStudentKey();

    const unreadCount = notifications.filter(notification =>
        notification.recipientKey === studentKey &&
        notification.read !== true
    ).length;

    badge.textContent = unreadCount > 99 ? "99+" : unreadCount;
    badge.hidden = unreadCount === 0;
}

// Update the badge when the student dashboard loads.
updateNotificationBadge();
