/* AKASHIC Prototype — Diagram Canvas (corrected version)
   Draggable flowchart shapes and connectors.
   No database or external libraries required.

   What was fixed:
   1. Loading this file twice no longer makes two canvases.
   2. Clicking "Insert Diagram" no longer triggers any other script.
   3. Errors show inside the canvas (alert boxes can be blocked by the browser).
   4. New diagrams are inserted where your cursor is (not always at the end).
   5. Long shape text wraps inside the inserted diagram too.
   6. "Remove from thesis" button when you re-open a diagram.
   7. Each inserted diagram has its own arrow IDs, so arrows never clash. */
(() => {
  "use strict";

  // If this file is loaded twice, stop here (prevents two canvases).
  if (window.akashicDiagramLoaded) return;
  window.akashicDiagramLoaded = true;

  const NS = "http://www.w3.org/2000/svg";
  const SHAPES = [
    "Rectangle", "Rounded rectangle", "Oval", "Diamond",
    "Triangle", "Parallelogram", "Hexagon", "Cylinder", "Document"
  ];
  const CONNECTORS = [
    "Line", "Arrow", "Double arrow", "Dashed line",
    "Dashed arrow", "Elbow connector", "Elbow arrow",
    "Elbow double arrow"
  ];

  let modal, svg;
  let editingDiagram = null;   // the diagram being edited (null = new diagram)
  let insertRange = null;      // where the cursor was in the thesis editor
  let selectedId = null;
  let nextId = 1;
  let activeTool = "select";
  let drag = null;
  let objects = [];
  let connectors = [];
  let firstConnectorShape = null;

  const $ = (selector, root = modal) => root.querySelector(selector);

  // Small helper that creates an SVG element with attributes.
  function make(tag, attrs = {}) {
    const element = document.createElementNS(NS, tag);
    Object.entries(attrs).forEach(([key, value]) =>
      element.setAttribute(key, value)
    );
    return element;
  }

  // ---------------------------------------------------
  // Build the canvas window (only once)
  // ---------------------------------------------------
  function ensureModal() {
    if (modal) return;

    // Remove an old leftover canvas if one exists.
    document.getElementById("akashicDiagramModal")?.remove();

    modal = document.createElement("div");
    modal.id = "akashicDiagramModal";

    modal.innerHTML = `
      <div class="akd-backdrop"></div>
      <section class="akd-window" role="dialog"
        aria-modal="true" aria-label="Diagram editor">

        <header class="akd-head">
          <div>
            <strong>AKASHIC Diagram Canvas</strong>
            <small>Drag shapes to move them. Connect shapes using the connector tool.</small>
          </div>
          <button type="button" class="akd-close" aria-label="Close">×</button>
        </header>

        <div class="akd-tools">
          <label>Shape
            <select class="akd-shape">
              ${SHAPES.map(s => `<option>${s}</option>`).join("")}
            </select>
          </label>
          <button type="button" data-action="add-shape">＋ Add shape</button>

          <label>Connector
            <select class="akd-connector">
              ${CONNECTORS.map(c => `<option>${c}</option>`).join("")}
            </select>
          </label>
          <button type="button" data-action="connect">Connect shapes</button>

          <label>Fill <input class="akd-fill" type="color" value="#e8f5e9"></label>
          <label>Border <input class="akd-border" type="color" value="#247447"></label>

          <button type="button" data-action="label">Edit label</button>
          <button type="button" data-action="delete">Delete selected</button>
          <button type="button" data-action="clear">Clear canvas</button>
        </div>

        <div class="akd-status" aria-live="polite">
          Add a shape or select an existing shape.
        </div>

        <div class="akd-canvas-wrap">
          <svg class="akd-canvas" viewBox="0 0 1000 600"
            xmlns="${NS}" aria-label="Diagram canvas">
            <defs>
              <marker id="akdArrow" markerWidth="10" markerHeight="10"
                refX="8" refY="3" orient="auto" markerUnits="strokeWidth">
                <path d="M0,0 L0,6 L9,3 z" fill="#334155"></path>
              </marker>
              <marker id="akdStartArrow" markerWidth="10" markerHeight="10"
                refX="1" refY="3" orient="auto" markerUnits="strokeWidth">
                <path d="M9,0 L9,6 L0,3 z" fill="#334155"></path>
              </marker>
            </defs>
            <g class="akd-connector-layer"></g>
            <g class="akd-shape-layer"></g>
          </svg>
        </div>

        <footer class="akd-foot">
          <span>Tip: Choose Connect shapes, then click two shapes.</span>
          <div>
            <button type="button" class="akd-remove" data-action="remove" hidden>
              Remove from thesis
            </button>
            <button type="button" data-action="cancel">Cancel</button>
            <button type="button" class="akd-save" data-action="save">
              Insert into thesis
            </button>
          </div>
        </footer>
      </section>`;

    const style = document.createElement("style");
    style.textContent = `
      #akashicDiagramModal {
        position:fixed; inset:0; z-index:99999;
        font:14px Arial,sans-serif; color:#173b2b;
      }
      #akashicDiagramModal * { box-sizing:border-box; }
      #akashicDiagramModal [hidden] { display:none !important; }
      #akashicDiagramModal .akd-backdrop {
        position:absolute; inset:0; background:#0f172a99;
      }
      #akashicDiagramModal .akd-window {
        position:absolute; inset:3vh 3vw; background:#f8fafc;
        border-radius:14px; box-shadow:0 20px 60px #0005;
        display:flex; flex-direction:column; overflow:hidden;
      }
      #akashicDiagramModal .akd-head {
        display:flex; justify-content:space-between; align-items:center;
        padding:14px 18px; background:#14532d; color:white; gap:16px;
        flex:none;
      }
      #akashicDiagramModal .akd-head strong {
        font-size:18px; display:block;
      }
      #akashicDiagramModal .akd-head small {
        display:block; margin-top:5px; color:#dcfce7;
      }
      #akashicDiagramModal button,
      #akashicDiagramModal select {
        font:inherit; color:#173b2b; border:1px solid #cbd5e1;
        border-radius:7px; padding:8px 10px;
        background:white; cursor:pointer;
      }
      #akashicDiagramModal button:hover { background:#dcfce7; }
      #akashicDiagramModal .akd-close {
        font-size:25px; line-height:1; padding:4px 11px;
      }
      #akashicDiagramModal .akd-tools {
        display:flex; align-items:center; gap:8px; flex:none;
        flex-wrap:wrap; padding:10px; background:#ecfdf5;
        border-bottom:1px solid #cbd5e1;
      }
      #akashicDiagramModal .akd-tools label {
        display:flex; align-items:center; gap:5px;
        font-size:12px; font-weight:700;
      }
      #akashicDiagramModal input[type=color] {
        width:34px; height:32px; padding:2px;
        border:1px solid #cbd5e1; border-radius:5px;
      }
      #akashicDiagramModal .akd-status {
        padding:7px 12px; font-size:12px; flex:none;
        color:#475569; background:white;
      }
      #akashicDiagramModal .akd-canvas-wrap {
        flex:1 1 0; min-height:0; overflow:auto; padding:12px;
        background-color:#e2e8f0;
        background-image:radial-gradient(#94a3b8 1px,transparent 1px);
        background-size:16px 16px;
      }
      #akashicDiagramModal .akd-canvas {
        display:block; width:100%; min-width:700px;
        aspect-ratio:1000 / 600; background:white;
        border:1px solid #cbd5e1; border-radius:6px;
        touch-action:none; box-shadow:0 2px 8px #0001;
      }
      #akashicDiagramModal .akd-foot {
        display:flex; align-items:center; justify-content:space-between;
        gap:10px; padding:12px 16px; background:white; flex:none;
        border-top:1px solid #cbd5e1; font-size:12px; color:#475569;
      }
      #akashicDiagramModal .akd-foot>div {
        display:flex; gap:8px; flex-wrap:wrap;
      }
      #akashicDiagramModal .akd-save {
        background:#166534!important; color:white!important;
        border-color:#166534!important;
      }
      #akashicDiagramModal .akd-remove {
        color:#b91c1c; border-color:#fca5a5;
      }
      #akashicDiagramModal .akd-shape-item { cursor:grab; }
      #akashicDiagramModal .akd-shape-item:active { cursor:grabbing; }
      #akashicDiagramModal .akd-shape-item.akd-selected .akd-outline {
        stroke:#2563eb!important; stroke-width:3!important;
        stroke-dasharray:5 3;
      }
      #akashicDiagramModal .akd-shape-item text {
        user-select:none; pointer-events:none;
        font:14px Arial,sans-serif; fill:#1f2937;
      }
      #akashicDiagramModal .akd-connector-item {
        fill:none; stroke:#334155; stroke-width:2.2;
        pointer-events:stroke; cursor:pointer;
      }
      #akashicDiagramModal .akd-connector-item.akd-selected {
        stroke:#2563eb; stroke-width:4;
      }

      /* How a saved diagram looks inside the thesis */
      .akd-thesis-diagram {
        display:block; max-width:100%; margin:16px auto; padding:6px;
        border:1px solid transparent; cursor:pointer; break-inside:avoid;
      }
      .akd-thesis-diagram:hover { border-color:#94a3b8; }
      .akd-thesis-diagram:focus { outline:2px solid #2563eb; }
      .akd-thesis-diagram svg {
        display:block; width:100%; max-width:100%; height:auto;
      }
    `;

    document.head.appendChild(style);
    document.body.appendChild(modal);

    svg = $(".akd-canvas");

    modal.addEventListener("click", onModalClick);
    svg.addEventListener("pointerdown", onPointerDown);
    svg.addEventListener("pointermove", onPointerMove);
    svg.addEventListener("pointerup", onPointerUp);
    svg.addEventListener("pointercancel", onPointerUp);

    $(".akd-fill").addEventListener("input", () =>
      styleSelected("fill", $(".akd-fill").value)
    );
    $(".akd-border").addEventListener("input", () =>
      styleSelected("stroke", $(".akd-border").value)
    );
  }

  function status(message) {
    if (modal) $(".akd-status").textContent = message;
  }

  // ---------------------------------------------------
  // Open / close
  // ---------------------------------------------------
  // Remember where the cursor is in the thesis so the diagram
  // can be inserted there.
  function rememberCursor() {
    insertRange = null;

    const editor = document.getElementById("thesisEditor");
    const selection = window.getSelection();

    if (editor && selection && selection.rangeCount) {
      const range = selection.getRangeAt(0);
      if (editor.contains(range.commonAncestorContainer)) {
        insertRange = range.cloneRange();
      }
    }
  }

  function openCanvas(diagramElement = null) {
    if (!diagramElement) rememberCursor();

    ensureModal();

    editingDiagram = diagramElement;
    $(".akd-remove").hidden = !diagramElement;

    if (diagramElement) {
      try {
        const data = JSON.parse(diagramElement.dataset.diagramData || "{}");

        objects = data.objects || [];
        connectors = data.connectors || [];
        nextId = data.nextId || 1;

        status("Editing existing diagram. Save to update it.");
        $(".akd-save").textContent = "Save Changes";
      } catch (error) {
        objects = [];
        connectors = [];
        nextId = 1;

        status("Could not load diagram data. Create a new diagram.");
        $(".akd-save").textContent = "Insert into thesis";
      }
    } else {
      objects = [];
      connectors = [];
      nextId = 1;

      status("Create your diagram, then insert it.");
      $(".akd-save").textContent = "Insert into thesis";
    }

    selectedId = null;
    activeTool = "select";
    drag = null;
    firstConnectorShape = null;

    render();
    modal.style.display = "block";
    document.body.style.overflow = "hidden";
  }

  function closeCanvas() {
    if (modal) modal.style.display = "none";
    document.body.style.overflow = "";
    drag = null;
    editingDiagram = null;
  }

  // ---------------------------------------------------
  // Drawing helpers
  // ---------------------------------------------------
  function getCanvasPoint(event) {
    const point = svg.createSVGPoint();
    point.x = event.clientX;
    point.y = event.clientY;
    return point.matrixTransform(svg.getScreenCTM().inverse());
  }

  function shapeSvg(o) {
    const { x, y, w, h } = o;
    const common = {
      class: "akd-outline", fill: o.fill,
      stroke: o.stroke, "stroke-width": 2
    };
    switch (o.type) {
      case "Rounded rectangle":
        return make("rect", { x, y, width: w, height: h, rx: 15, ...common });
      case "Oval":
        return make("ellipse", {
          cx: x + w / 2, cy: y + h / 2, rx: w / 2, ry: h / 2, ...common
        });
      case "Diamond":
        return make("polygon", {
          points: `${x + w / 2},${y} ${x + w},${y + h / 2} ${x + w / 2},${y + h} ${x},${y + h / 2}`,
          ...common
        });
      case "Triangle":
        return make("polygon", {
          points: `${x + w / 2},${y} ${x + w},${y + h} ${x},${y + h}`,
          ...common
        });
      case "Parallelogram":
        return make("polygon", {
          points: `${x + 22},${y} ${x + w},${y} ${x + w - 22},${y + h} ${x},${y + h}`,
          ...common
        });
      case "Hexagon":
        return make("polygon", {
          points: `${x + 20},${y} ${x + w - 20},${y} ${x + w},${y + h / 2} ${x + w - 20},${y + h} ${x + 20},${y + h} ${x},${y + h / 2}`,
          ...common
        });
      case "Cylinder":
        return make("path", {
          d: `M ${x} ${y + 12} C ${x} ${y - 4},${x + w} ${y - 4},${x + w} ${y + 12} L ${x + w} ${y + h - 12} C ${x + w} ${y + h + 4},${x} ${y + h + 4},${x} ${y + h - 12} Z`,
          ...common
        });
      case "Document":
        return make("path", {
          d: `M ${x} ${y} H ${x + w} V ${y + h - 12} Q ${x + w * .75} ${y + h + 6} ${x + w * .5} ${y + h - 12} T ${x} ${y + h - 12} Z`,
          ...common
        });
      default:
        return make("rect", { x, y, width: w, height: h, ...common });
    }
  }

  // Split a long label into lines of about 17 characters (max 4 lines).
  function wrapLabel(label) {
    const words = String(label || "").split(/\s+/).filter(Boolean);
    const lines = [];
    let line = "";

    words.forEach(word => {
      if ((line + " " + word).trim().length > 17) {
        if (line) lines.push(line);
        line = word;
      } else {
        line = (line + " " + word).trim();
      }
    });

    if (line) lines.push(line);
    return lines.slice(0, 4);
  }

  // Build the label text for a shape (used by the canvas AND the thesis copy).
  function labelText(o, extra = {}) {
    const cx = o.x + o.w / 2;
    const cy = o.y + o.h / 2;
    const lines = wrapLabel(o.label);

    const text = make("text", {
      x: cx, y: cy,
      "text-anchor": "middle", "dominant-baseline": "middle",
      ...extra
    });

    lines.forEach((ln, i) => {
      const tspan = make("tspan", {
        x: cx,
        dy: i === 0 ? `${-(lines.length - 1) * 9}px` : "18px"
      });
      tspan.textContent = ln;
      text.appendChild(tspan);
    });

    return text;
  }

  function center(o) {
    return { x: o.x + o.w / 2, y: o.y + o.h / 2 };
  }

  function connectorPath(a, b, type) {
    const p = center(a), q = center(b);
    if (type.startsWith("Elbow")) {
      const mid = (p.x + q.x) / 2;
      return `M ${p.x} ${p.y} L ${mid} ${p.y} L ${mid} ${q.y} L ${q.x} ${q.y}`;
    }
    return `M ${p.x} ${p.y} L ${q.x} ${q.y}`;
  }

  function render() {
    const connectorLayer = $(".akd-connector-layer");
    const shapeLayer = $(".akd-shape-layer");
    connectorLayer.replaceChildren();
    shapeLayer.replaceChildren();

    connectors.forEach(c => {
      const a = objects.find(o => o.id === c.from);
      const b = objects.find(o => o.id === c.to);
      if (!a || !b) return;

      const path = make("path", {
        d: connectorPath(a, b, c.type),
        class: "akd-connector-item" + (selectedId === c.id ? " akd-selected" : ""),
        "data-id": c.id
      });

      if (c.type.includes("Dashed")) path.setAttribute("stroke-dasharray", "7 5");
      if (/arrow/i.test(c.type)) path.setAttribute("marker-end", "url(#akdArrow)");
      if (/double arrow/i.test(c.type)) path.setAttribute("marker-start", "url(#akdStartArrow)");

      connectorLayer.appendChild(path);
    });

    objects.forEach(o => {
      const group = make("g", {
        class: "akd-shape-item" + (selectedId === o.id ? " akd-selected" : ""),
        "data-id": o.id
      });

      group.appendChild(shapeSvg(o));
      group.appendChild(labelText(o));
      shapeLayer.appendChild(group);
    });
  }

  // ---------------------------------------------------
  // Buttons inside the canvas
  // ---------------------------------------------------
  function addShape() {
    const type = $(".akd-shape").value;
    const o = {
      id: "s" + nextId++,
      type,
      label: type === "Diamond" ? "Decision" : "Enter text",
      x: 90 + (objects.length % 4) * 205,
      y: 75 + Math.floor(objects.length / 4) * 135,
      w: 150, h: 76,
      fill: $(".akd-fill").value,
      stroke: $(".akd-border").value
    };

    objects.push(o);
    selectedId = o.id;
    activeTool = "select";
    render();
    status("Shape added. Drag it to move, or choose Edit label.");
  }

  function onModalClick(event) {
    const action = event.target.closest("[data-action]")?.dataset.action;

    if (event.target.closest(".akd-close") ||
        event.target.classList.contains("akd-backdrop") ||
        action === "cancel") {
      closeCanvas();
      return;
    }

    if (action === "add-shape") addShape();

    if (action === "connect") {
      activeTool = "connect";
      firstConnectorShape = null;
      status("Click the first shape, then click the destination shape.");
    }

    if (action === "label") {
      const object = objects.find(o => o.id === selectedId);
      if (!object) {
        status("Select a shape first.");
        return;
      }
      const label = prompt("Shape label:", object.label);
      if (label !== null) {
        object.label = label;
        render();
      }
    }

    if (action === "delete") {
      objects = objects.filter(o => o.id !== selectedId);
      connectors = connectors.filter(c =>
        c.id !== selectedId && c.from !== selectedId && c.to !== selectedId
      );
      selectedId = null;
      render();
    }

    if (action === "clear" &&
        confirm("Clear all shapes and connectors from this canvas?")) {
      objects = [];
      connectors = [];
      selectedId = null;
      render();
    }

    if (action === "remove") removeDiagram();
    if (action === "save") saveDiagram();
  }

  // ---------------------------------------------------
  // Mouse / touch on the canvas
  // ---------------------------------------------------
  function onPointerDown(event) {
    const shape = event.target.closest(".akd-shape-item");
    const connector = event.target.closest(".akd-connector-item");

    if (connector) {
      selectedId = connector.dataset.id;
      render();
      return;
    }

    if (!shape) {
      selectedId = null;
      render();
      return;
    }

    const id = shape.dataset.id;

    if (activeTool === "connect") {
      if (!firstConnectorShape) {
        firstConnectorShape = id;
        status("First shape selected. Now click the destination shape.");
      } else if (firstConnectorShape !== id) {
        connectors.push({
          id: "c" + nextId++,
          from: firstConnectorShape,
          to: id,
          type: $(".akd-connector").value
        });
        selectedId = connectors[connectors.length - 1].id;
        firstConnectorShape = null;
        activeTool = "select";
        render();
        status("Connector added. It will follow the shapes when moved.");
      }
      return;
    }

    selectedId = id;
    const object = objects.find(o => o.id === id);
    const point = getCanvasPoint(event);

    drag = {
      id,
      dx: point.x - object.x,
      dy: point.y - object.y,
      pointerId: event.pointerId
    };

    svg.setPointerCapture(event.pointerId);
    render();
  }

  function onPointerMove(event) {
    if (!drag) return;

    const object = objects.find(o => o.id === drag.id);
    if (!object) return;

    const point = getCanvasPoint(event);
    object.x = Math.max(0, Math.min(1000 - object.w, point.x - drag.dx));
    object.y = Math.max(0, Math.min(600 - object.h, point.y - drag.dy));

    render();
  }

  function onPointerUp() {
    drag = null;
  }

  function styleSelected(property, value) {
    const object = objects.find(o => o.id === selectedId);
    if (!object) return;
    object[property] = value;
    render();
  }

  // ---------------------------------------------------
  // Insert / update / remove the diagram in the thesis
  // ---------------------------------------------------
  // Tell the main script that the thesis text changed (so auto-save runs).
  function tellEditorChanged(editor) {
    editor.dispatchEvent(new Event("input", { bubbles: true }));
  }

  // Put a new diagram right after the paragraph where the cursor was.
  function placeWrapper(editor, wrapper) {
    if (insertRange) {
      const node = insertRange.endContainer;

      if (node === editor) {
        // Cursor is directly in the editor box.
        editor.insertBefore(wrapper, editor.childNodes[insertRange.endOffset] || null);
        return;
      }

      // Find the paragraph (direct child of the editor) holding the cursor.
      let block = node;
      while (block && block.parentNode !== editor) block = block.parentNode;

      if (block) {
        block.after(wrapper);
        return;
      }
    }

    editor.appendChild(wrapper); // no cursor known: put it at the end
  }

  function saveDiagram() {
    if (!objects.length) {
      status("Add at least one shape before inserting.");
      return;
    }

    const editor = document.getElementById("thesisEditor");

    if (!editor) {
      status("Open a thesis chapter first (Thesis Editor page).");
      return;
    }

    try {
      const data = {
        objects: JSON.parse(JSON.stringify(objects)),
        connectors: JSON.parse(JSON.stringify(connectors)),
        nextId
      };

      let wrapper = editingDiagram;
      const isNew = !wrapper || !editor.contains(wrapper);

      if (isNew) {
        wrapper = document.createElement("div");
        wrapper.className = "akd-thesis-diagram";
        wrapper.contentEditable = "false";
        wrapper.tabIndex = 0;
        wrapper.setAttribute("role", "button");
        wrapper.setAttribute("aria-label", "Click to edit diagram");
        wrapper.style.cssText =
          "display:block;max-width:100%;margin:16px auto;" +
          "padding:6px;border:1px solid #d1d5db;background:white;" +
          "cursor:pointer;break-inside:avoid;";
      }

      wrapper.dataset.diagramData = JSON.stringify(data);

      // Every diagram gets its own arrow IDs so diagrams never clash.
      const uid = "akd" + Date.now().toString(36) + Math.floor(Math.random() * 1000);

      const output = make("svg", {
        xmlns: NS,
        viewBox: "0 0 1000 600",
        width: "100%",
        role: "img",
        "aria-label": "Thesis diagram",
        style: "display:block;width:100%;height:auto;"
      });

      const defs = make("defs");

      const endMarker = make("marker", {
        id: uid + "e", markerWidth: 10, markerHeight: 10,
        refX: 8, refY: 3, orient: "auto"
      });
      endMarker.appendChild(make("path", { d: "M0,0 L0,6 L9,3 z", fill: "#334155" }));

      const startMarker = make("marker", {
        id: uid + "s", markerWidth: 10, markerHeight: 10,
        refX: 1, refY: 3, orient: "auto"
      });
      startMarker.appendChild(make("path", { d: "M9,0 L9,6 L0,3 z", fill: "#334155" }));

      defs.append(endMarker, startMarker);
      output.appendChild(defs);

      const connectorLayer = make("g");
      const shapeLayer = make("g");

      connectors.forEach(c => {
        const a = objects.find(o => o.id === c.from);
        const b = objects.find(o => o.id === c.to);
        if (!a || !b) return;

        const path = make("path", {
          d: connectorPath(a, b, c.type),
          fill: "none",
          stroke: "#334155",
          "stroke-width": 2.2
        });

        if (c.type.includes("Dashed")) path.setAttribute("stroke-dasharray", "7 5");
        if (/arrow/i.test(c.type)) path.setAttribute("marker-end", `url(#${uid}e)`);
        if (/double arrow/i.test(c.type)) path.setAttribute("marker-start", `url(#${uid}s)`);

        connectorLayer.appendChild(path);
      });

      objects.forEach(o => {
        shapeLayer.appendChild(shapeSvg(o));
        shapeLayer.appendChild(labelText(o, {
          fill: "#1f2937",
          style: "font:14px Arial,sans-serif"
        }));
      });

      output.append(connectorLayer, shapeLayer);
      wrapper.replaceChildren(output);

      if (isNew) {
        placeWrapper(editor, wrapper);
      }

      // Make sure there is a paragraph after the diagram to keep typing.
      const next = wrapper.nextElementSibling;
      if (!next || next.tagName !== "P") {
        const paragraph = document.createElement("p");
        paragraph.innerHTML = "<br>";
        wrapper.after(paragraph);
      }

      tellEditorChanged(editor);
      closeCanvas();
    } catch (error) {
      console.error("AKASHIC diagram save failed:", error);
      status("Insert failed: " + error.message + " (press F12 > Console for details)");
    }
  }

  function removeDiagram() {
    if (!editingDiagram) return;
    if (!confirm("Remove this diagram from the thesis?")) return;

    const editor = document.getElementById("thesisEditor");
    editingDiagram.remove();

    if (editor) tellEditorChanged(editor);
    closeCanvas();
  }

  // ---------------------------------------------------
  // Open the canvas from the page
  // ---------------------------------------------------
  // This runs BEFORE any other click code on the page (capture mode),
  // and stopPropagation() stops other scripts from reacting to the same click.
  document.addEventListener("click", event => {
    // Clicks inside the canvas window are handled by the canvas itself.
    if (event.target.closest("#akashicDiagramModal")) return;

    if (event.target.closest("#insertDiagram")) {
      event.preventDefault();
      event.stopPropagation();
      openCanvas();
      return;
    }

    const diagram = event.target.closest(".akd-thesis-diagram");

    if (diagram) {
      event.preventDefault();
      event.stopPropagation();
      openCanvas(diagram);
    }
  }, true);

  // Press Esc to close the canvas.
  document.addEventListener("keydown", event => {
    if (event.key === "Escape" && modal && modal.style.display === "block") {
      closeCanvas();
    }
  });
})();