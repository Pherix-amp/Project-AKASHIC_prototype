const SUBMISSIONS_KEY = "akashicSubmissions";

const rowsContainer = document.getElementById("facultySubmissionRows");
const statusFilter = document.getElementById("facultyStatusFilter");
const searchInput = document.getElementById("facultySearch");


 // Display the currently logged-in faculty account.
try {
    const savedAccount = JSON.parse(
       sessionStorage.getItem("akashicDemoAccount") || "null"
    );

    if (!savedAccount || savedAccount.role !== "faculty") {
        window.location.replace("login.html");
    } else {
        document.getElementById("facultyName").textContent =
            savedAccount.fullName || "Faculty / Adviser";
    }
} catch (error) {
    console.warn("Could not load faculty account.", error);
    window.location.replace("login.html");
}


// Log out without deleting saved submissions.
document.getElementById("facultyLogout").addEventListener("click", () => {
    const confirmed = confirm("Are you sure you want to log out?");

    if (!confirmed) return;

    localStorage.removeItem("akashicDemoAccount");
    window.location.href = "login.html";
});

function getSubmissions() {
    try {
        const records = JSON.parse(
            localStorage.getItem(SUBMISSIONS_KEY) || "[]"
        );

        return Array.isArray(records) ? records : [];
    } catch (error) {
        console.error("Could not load submissions:", error);
        return [];
    }
}

function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, character => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[character]);
}

function formatDate(value) {
    const date = new Date(value);

    return Number.isNaN(date.getTime())
        ? "Unknown date"
        : date.toLocaleString();
}

function renderFacultyDashboard() {
    const submissions = getSubmissions();

    // Only these review statuses belong in the faculty queue.
    // Flagged submissions are deliberately excluded.
    const reviewSubmissions = submissions.filter(submission =>
        [
            "pending_faculty_review",
            "approved",
            "revision_requested"
        ].includes(submission.status)
    );

    const awaitingCount = reviewSubmissions.filter(
        submission => submission.status === "pending_faculty_review"
    ).length;

    const approvedCount = reviewSubmissions.filter(
        submission => submission.status === "approved"
    ).length;

    const revisionCount = reviewSubmissions.filter(
        submission => submission.status === "revision_requested"
    ).length;

    document.getElementById("awaitingCount").textContent =
        awaitingCount;

    document.getElementById("approvedCount").textContent =
        approvedCount;

    document.getElementById("revisionCount").textContent =
        revisionCount;

    const selectedStatus = statusFilter.value;

    const searchTerm = searchInput.value.trim().toLowerCase();

const visibleSubmissions = reviewSubmissions
    .filter(submission =>
        selectedStatus === "all" ||
        submission.status === selectedStatus
    )
    .filter(submission => {
        const searchableText = [
            submission.chapterLabel,
            submission.groupTitle,
            submission.submittedBy
        ].join(" ").toLowerCase();

        return searchableText.includes(searchTerm);
    })
    .sort((a, b) => new Date(b.submittedAt) - new Date(a.submittedAt));

    rowsContainer.innerHTML = visibleSubmissions.map(submission => {
        let statusLabel = "Awaiting Review";

        if (submission.status === "approved") {
            statusLabel = "Approved";
        } else if (submission.status === "revision_requested") {
            statusLabel = "Revisions Requested";
        }

        return `
            <tr>
                <td>
                    <strong>${escapeHTML(submission.chapterLabel)}</strong>
                    <p class="faculty-muted">
                        ${escapeHTML(submission.groupTitle || "Demo Thesis Group")}
                    </p>
                </td>

                <td>${escapeHTML(submission.submittedBy || "Demo Student")}</td>

                <td>${escapeHTML(formatDate(submission.submittedAt))}</td>

                <td>
                    <span class="faculty-status">
                        ${escapeHTML(statusLabel)}
                    </span>
                </td>

                <td>
                    <button
                        type="button"
                        class="faculty-view-button"
                        data-submission-id="${escapeHTML(submission.id)}"
                    >
                        View Submission
                    </button>
                </td>
            </tr>
        `;
    }).join("");
}

statusFilter.addEventListener("change", renderFacultyDashboard);
searchInput.addEventListener("input", renderFacultyDashboard);


rowsContainer.addEventListener("click", event => {
    const button = event.target.closest("[data-submission-id]");
    if (!button) return;

    const submissionId = button.dataset.submissionId;
    const submission = getSubmissions().find(
        item => item.id === submissionId
    );

    if (!submission) {
        alert("Submission not found. Please refresh the dashboard.");
        return;
    }

    // Store the selected submission ID for the review workspace.
    sessionStorage.setItem("akashicSelectedSubmissionId", submission.id);

    // Open the review workspace.
    window.location.href = "faculty-review.html";
});


renderFacultyDashboard();
