
const SUBMISSIONS_KEY = "akashicSubmissions";
const SELECTED_SUBMISSION_KEY = "akashicSelectedSubmissionId";

function getSubmissions() {
    try {
        const records = JSON.parse(
            localStorage.getItem(SUBMISSIONS_KEY) || "[]"
        );

        return Array.isArray(records) ? records : [];
    } catch (error) {
        console.error("Could not load submissions:", error);
        return [];
    }
}

function saveSubmissions(submissions) {
    localStorage.setItem(
        SUBMISSIONS_KEY,
        JSON.stringify(submissions)
    );
}

function safeChapterHTML(html) {
    const template = document.createElement("template");
    template.innerHTML = html || "<p>No saved chapter content found.</p>";

    template.content.querySelectorAll(
        "script, iframe, object, embed, form"
    ).forEach(element => element.remove());

    template.content.querySelectorAll("*").forEach(element => {
        Array.from(element.attributes).forEach(attribute => {
            const name = attribute.name.toLowerCase();
            const value = attribute.value.trim().toLowerCase();

            if (
                name.startsWith("on") ||
                (
                    (name === "href" || name === "src") &&
                    value.startsWith("javascript:")
                )
            ) {
                element.removeAttribute(attribute.name);
            }
        });
    });

    return template.innerHTML;
}

function getSelectedSubmission() {
    const selectedId = sessionStorage.getItem(
        SELECTED_SUBMISSION_KEY
    );

    return getSubmissions().find(
        submission => submission.id === selectedId
    );
}

function loadSelectedSubmission() {
    const submission = getSelectedSubmission();

    const chapterTitle = document.getElementById("reviewChapterTitle");
    const studentName = document.getElementById("reviewStudentName");
    const submissionStatus = document.getElementById(
        "reviewSubmissionStatus"
    );
    const chapterContent = document.getElementById(
        "submittedChapterContent"
    );

    if (!submission) {
        chapterTitle.textContent = "No submission selected";
        studentName.textContent = "Not available";
        submissionStatus.textContent = "Not loaded";
        chapterContent.textContent =
            "No submission selected. Return to the Faculty Dashboard and choose View Submission.";
        return;
    }

    chapterTitle.textContent =
        submission.chapterLabel || submission.chapter || "Untitled Chapter";

    studentName.textContent =
        submission.submittedBy || "Student";

    submissionStatus.textContent =
        submission.statusLabel || submission.status || "Pending review";

    chapterContent.innerHTML = safeChapterHTML(
        submission.snapshotHTML
    );

    // Load previously saved feedback, if available.
    const feedback = submission.reviewFeedback || {};

    document.getElementById("generalComment").value =
        feedback.generalComment || "";

    document.getElementById("originalText").value =
        feedback.originalText || "";

    document.getElementById("suggestedText").value =
        feedback.suggestedText || "";
}

function saveFeedback() {
    const selectedId = sessionStorage.getItem(
        SELECTED_SUBMISSION_KEY
    );

    const submissions = getSubmissions();

    const index = submissions.findIndex(
        submission => submission.id === selectedId
    );

    if (index === -1) {
        alert("Submission not found. Return to the Faculty Dashboard and open it again.");
        return;
    }

    const generalComment = document
        .getElementById("generalComment").value.trim();

    const originalText = document
        .getElementById("originalText").value.trim();

    const suggestedText = document
        .getElementById("suggestedText").value.trim();

    if (!generalComment && !originalText && !suggestedText) {
        alert("Please enter a comment or suggested edit before saving.");
        return;
    }

    const existingFeedback =
        submissions[index].reviewFeedback || {};

    submissions[index].reviewFeedback = {
        ...existingFeedback,
        generalComment,
        originalText,
        suggestedText,
        savedAt: new Date().toISOString()
    };

    try {
        saveSubmissions(submissions);
        alert("Feedback saved successfully.");
    } catch (error) {
        console.error("Could not save feedback:", error);
        alert("Feedback could not be saved. Please try again.");
    }
}

document.getElementById("saveFeedback").addEventListener(
    "click",
    saveFeedback
);

loadSelectedSubmission();

const NOTIFICATIONS_KEY = "akashicNotifications";

function requestRevisions() {
    const selectedId = sessionStorage.getItem(
        SELECTED_SUBMISSION_KEY
    );

    const submissions = getSubmissions();

    const index = submissions.findIndex(
        submission => submission.id === selectedId
    );

    if (index === -1) {
        alert("Submission not found. Please return to the Faculty Dashboard and open it again.");
        return;
    }

    const generalComment = document
        .getElementById("generalComment").value.trim();

    const originalText = document
        .getElementById("originalText").value.trim();

    const suggestedText = document
        .getElementById("suggestedText").value.trim();

    if (!generalComment && !suggestedText) {
        alert("Please provide feedback or a suggested edit before requesting revisions.");
        return;
    }

    const confirmed = confirm(
        "Request revisions for this chapter and notify the student?"
    );

    if (!confirmed) return;

    const submission = submissions[index];

    // Save the faculty feedback without changing the submitted chapter.
    submission.reviewFeedback = {
        ...(submission.reviewFeedback || {}),
        generalComment,
        originalText,
        suggestedText,
        savedAt: new Date().toISOString()
    };

    submission.status = "revision_requested";
    submission.statusLabel = "Revisions Requested";
    submission.decision = "revision_requested";
    submission.reviewedAt = new Date().toISOString();

    try {
        saveSubmissions(submissions);

        // Create an in-app notification for this student.
        const notifications = JSON.parse(
            localStorage.getItem(NOTIFICATIONS_KEY) || "[]"
        );

        notifications.push({
            id: `notification-${Date.now()}`,
            recipientKey: submission.submitterKey || "",
            title: "Chapter Revisions Requested",
            message: `Your submission "${submission.chapterLabel || submission.chapter || "Chapter"}" has been reviewed. Please check the faculty feedback and revise your chapter.`,
            type: "revision_requested",
            submissionId: submission.id,
            createdAt: new Date().toISOString(),
            read: false
        });

        localStorage.setItem(
            NOTIFICATIONS_KEY,
            JSON.stringify(notifications)
        );

        document.getElementById("reviewSubmissionStatus").textContent =
            "Revisions Requested";

        alert(
            "Revisions requested. The feedback and notification have been saved."
        );
    } catch (error) {
        console.error("Could not save revision request:", error);
        alert("Could not save the revision request. Please try again.");
    }
}

document.getElementById("requestRevisions").addEventListener(
    "click",
    requestRevisions
);

function approveChapter() {
    const selectedId = sessionStorage.getItem(
        SELECTED_SUBMISSION_KEY
    );

    const submissions = getSubmissions();

    const index = submissions.findIndex(
        submission => submission.id === selectedId
    );

    if (index === -1) {
        alert("Submission not found. Return to the Faculty Dashboard and open it again.");
        return;
    }

    const confirmed = confirm(
        "Approve this chapter? The student will be notified."
    );

    if (!confirmed) return;

    const submission = submissions[index];

    submission.reviewFeedback = {
        ...(submission.reviewFeedback || {}),
        generalComment: document
            .getElementById("generalComment").value.trim(),
        originalText: document
            .getElementById("originalText").value.trim(),
        suggestedText: document
            .getElementById("suggestedText").value.trim(),
        savedAt: new Date().toISOString()
    };

    submission.status = "approved";
    submission.statusLabel = "Approved";
    submission.decision = "approved";
    submission.reviewedAt = new Date().toISOString();

    try {
        saveSubmissions(submissions);

        const notifications = JSON.parse(
            localStorage.getItem(NOTIFICATIONS_KEY) || "[]"
        );

        notifications.push({
            id: `notification-${Date.now()}`,
            recipientKey: submission.submitterKey || "",
            title: "Chapter Approved",
            message: `Your submission "${submission.chapterLabel || submission.chapter || "Chapter"}" has been approved by the faculty.`,
            type: "approved",
            submissionId: submission.id,
            createdAt: new Date().toISOString(),
            read: false
        });

        localStorage.setItem(
            NOTIFICATIONS_KEY,
            JSON.stringify(notifications)
        );

        document.getElementById("reviewSubmissionStatus").textContent =
            "Approved";

        alert("Chapter approved. The decision and notification have been saved.");
    } catch (error) {
        console.error("Could not approve chapter:", error);
        alert("Could not save the approval. Please try again.");
    }
}

document.getElementById("approveChapter").addEventListener(
    "click",
    approveChapter
);
